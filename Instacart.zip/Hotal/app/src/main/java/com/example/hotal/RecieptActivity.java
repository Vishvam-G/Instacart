package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class RecieptActivity extends AppCompatActivity {

    TextView ref,v1,paymode;
    Button h1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reciept);
        ref=findViewById(R.id.random);
        h1=findViewById(R.id.home);
        v1=findViewById(R.id.value);
        paymode=findViewById(R.id.pm);

        Intent v=getIntent();
        String amt=v.getStringExtra("Bill_Amt");
        String pm1=v.getStringExtra("pay_meth");
        v1.setText(amt);
        paymode.setText(pm1);
        ref.setText("Refrence Number : "+(int)(Math.random()*1000000000));
        h1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent home1=new Intent(RecieptActivity.this,MainActivity.class);
                startActivity(home1);
            }
        });
    }
}