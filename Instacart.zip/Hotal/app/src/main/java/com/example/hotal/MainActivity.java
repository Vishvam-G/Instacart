package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity
{
    LinearLayout s1,s2,s3,s4,s5;
    ImageView a1,a2,a3,a4;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s1=findViewById(R.id.jungleHotel);
        s2=findViewById(R.id.aubHotel);
        s3=findViewById(R.id.moonHotel);
        s4=findViewById(R.id.lakeHotel);
        s5=findViewById(R.id.off);
        a1=findViewById(R.id.nv_meal);
        a2=findViewById(R.id.stake);
        a3=findViewById(R.id.mini_combo);
        a4=findViewById(R.id.punjabi_tali);

        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(MainActivity.this,MenuActivity.class);
                i1.putExtra("HotelName","Jungle Restaurant");
                startActivity(i1);
            }
        });

        s2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(MainActivity.this,MenuActivity.class);
                i2.putExtra("HotelName","Aubrey's Restaurant");
                startActivity(i2);
            }
        });

        s3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3=new Intent(MainActivity.this,MenuActivity.class);
                i3.putExtra("HotelName","Moon Light Restaurant");
                startActivity(i3);
            }
        });

        s4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i4=new Intent(MainActivity.this,MenuActivity.class);
                i4.putExtra("HotelName","Lake Restaurant");
                startActivity(i4);
            }
        });
        s5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i5=new Intent(MainActivity.this,MenuActivity.class);
                startActivity(i5);
            }
        });
    }
}