package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity
{
    TextView hotelTV;
    LinearLayout w1,m1,m2,m3,m4,m5,m6;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        hotelTV=findViewById(R.id.hotelTitle);
        //w1=findViewById(R.id.menu);
        m1=findViewById(R.id.sandwich);
        m2=findViewById(R.id.burger);
        m3=findViewById(R.id.attho);
        m4=findViewById(R.id.crispy);
        m5=findViewById(R.id.jsandwich);
        m6=findViewById(R.id.burgerc);

        Intent i=getIntent();
        String hotelName=i.getStringExtra("HotelName");
        hotelTV.setText(hotelName);

        /*w1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n1=new Intent(MenuActivity.this, OrderActivity.class);
                startActivity(n1);
            }
        });*/



        m1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a1=new Intent(MenuActivity.this,OrderActivity.class);
                a1.putExtra("Food",R.drawable.b4);
                a1.putExtra("FoodName","Sandwich");
                a1.putExtra("Price","100");
                a1.putExtra("Discription","Price : Rs.₹100\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(a1);

            //    Intent b1=new Intent(MenuActivity.this,BillActivity.class);
              //  b1.putExtra("Price","100");
                //b1.putExtra("FoodName","Sandwich");
            }
        });

        m2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a2=new Intent(MenuActivity.this,OrderActivity.class);
                a2.putExtra("Food",R.drawable.b1);
                a2.putExtra("FoodName","Jombo Burger");
                a2.putExtra("Price","120");
                a2.putExtra("Discription","Price : Rs.₹120\nIt's Hygenic and get more calories with less oil and fat.");
                startActivity(a2);

               // Intent b2=new Intent(MenuActivity.this,OrderActivity.class);
                //b2.putExtra("Price","120");
                //b2.putExtra("FoodName","Jumbo Burger");
            }
        });

        m3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a3=new Intent(MenuActivity.this,OrderActivity.class);
                a3.putExtra("Food",R.drawable.b3);
                a3.putExtra("FoodName","Attho");
                a3.putExtra("Price","140");
                a3.putExtra("Discription","Price : Rs.₹140\nIt's a type of street food with little bit spicy , prepared with nooddle and eggs.");
                startActivity(a3);


            //    Intent b3=new Intent(MenuActivity.this,BillActivity.class);
              //  b3.putExtra("Price","140");
                //b3.putExtra("FoodName","Attho");
            }
        });

        m4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a4=new Intent(MenuActivity.this,OrderActivity.class);
                a4.putExtra("Food",R.drawable.b2);
                a4.putExtra("FoodName","Crispy Chicken");
                a4.putExtra("Price","220");
                a4.putExtra("Discription","Price : Rs.₹220\nIt's Prepared with less oil and its good for gain weight too.");
                startActivity(a4);

            //    Intent b4=new Intent(MenuActivity.this,BillActivity.class);
              //  b4.putExtra("Price","220");
                //b4.putExtra("FoodName","Crispy Chicken");
            }
        });
        m5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a5=new Intent(MenuActivity.this,OrderActivity.class);
                a5.putExtra("Food",R.drawable.b5);
                a5.putExtra("FoodName","Jumbo Sandwich");
                a5.putExtra("Price","230");
                a5.putExtra("Discription","Price : Rs.₹230\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(a5);

            //    Intent b5=new Intent(MenuActivity.this,BillActivity.class);
              //  b5.putExtra("Price","230");
                //b5.putExtra("FoodName","Jumbo Sandwich");
            }
        });
        m6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a6=new Intent(MenuActivity.this,OrderActivity.class);
                a6.putExtra("Food",R.drawable.b6);
                a6.putExtra("FoodName","Burger Combo");
                a6.putExtra("Price","250");
                a6.putExtra("Discription","Price : Rs.₹250\nThis combo consists of 1-Burger(mid), 1-Fries(mid), 1-Coke(unlimited).");
                startActivity(a6);

            //    Intent b6=new Intent(MenuActivity.this,BillActivity.class);
              //  b6.putExtra("Price","250");
                //b6.putExtra("FoodName","Burger Combo");
            }
        });
    }
}