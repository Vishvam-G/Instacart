package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class OrderActivity extends AppCompatActivity {

    TextView name,dis,quant,error;
    ImageView plus,minus,food;

    int val;
    Button bill;

    int i=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        food = findViewById(R.id.food);
        name = findViewById(R.id.name);
        dis = findViewById(R.id.discrip);
        quant = findViewById(R.id.count);
        plus = findViewById(R.id.pos);
        minus = findViewById(R.id.neg);
        bill = findViewById(R.id.bill1);
        error = findViewById(R.id.error1);

        Intent o = getIntent();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
        {
            val = bundle.getInt("Food");
        }
        food.setImageResource(val);
        String foodname = o.getStringExtra("FoodName");
        name.setText(foodname);
        String discrip = o.getStringExtra("Discription");
        dis.setText(discrip);

        String price=o.getStringExtra("Price");

        quant.setText(String.valueOf(i));


        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                quant.setText(String.valueOf(++i));
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i<=1)
                {
                    return;
                }
                else
                {
                    quant.setText(String.valueOf(--i));
                }
            }
        });

        bill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p1 = new Intent(OrderActivity.this, BillActivity.class);
                p1.putExtra("Quantity",String.valueOf(i));
                p1.putExtra("FoodName",foodname);
                p1.putExtra("Price",price);
                startActivity(p1);
            }
        });
    }
}