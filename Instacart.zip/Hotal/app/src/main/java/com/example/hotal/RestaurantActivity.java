package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class RestaurantActivity extends AppCompatActivity {

    LinearLayout s1,s2,s3,s4,s5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        s1=findViewById(R.id.jungleHotel);
        s2=findViewById(R.id.aubHotel);
        s3=findViewById(R.id.moonHotel);
        s4=findViewById(R.id.lakeHotel);

        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(RestaurantActivity.this,MenuActivity.class);
                i1.putExtra("Food",R.drawable.b4);
                i1.putExtra("FoodName","Sandwich");
                i1.putExtra("Price","100");
                i1.putExtra("Discription","Price : Rs.₹100\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(i1);
            }
        });
        s2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(RestaurantActivity.this,MenuActivity.class);
                i2.putExtra("Food",R.drawable.b4);
                i2.putExtra("FoodName","Sandwich");
                i2.putExtra("Price","100");
                i2.putExtra("Discription","Price : Rs.₹100\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(i2);
            }
        });

        s3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3=new Intent(RestaurantActivity.this,MenuActivity.class);
                i3.putExtra("Food",R.drawable.b4);
                i3.putExtra("FoodName","Sandwich");
                i3.putExtra("Price","100");
                i3.putExtra("Discription","Price : Rs.₹100\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(i3);
            }
        });

        s4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i4=new Intent(RestaurantActivity.this,MenuActivity.class);
                i4.putExtra("Food",R.drawable.b4);
                i4.putExtra("FoodName","Sandwich");
                i4.putExtra("Price","100");
                i4.putExtra("Discription","Price : Rs.₹100\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(i4);
            }
        });
        s5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i5=new Intent(RestaurantActivity.this,MenuActivity.class);
                i5.putExtra("Food",R.drawable.b4);
                i5.putExtra("FoodName","Sandwich");
                i5.putExtra("Price","100");
                i5.putExtra("Discription","Price : Rs.₹100\nIt's a healthy food item prepared with veggies and bread.");
                startActivity(i5);
            }
        });

    }
}