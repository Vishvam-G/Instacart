package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import java.text.DecimalFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class BillActivity extends AppCompatActivity
{
    TextView name,quant,price,tot,tot_bill,e;
    Button paymode;
    static double val;

    //static final DecimalFormat decfor = new DecimalFormat("0.000");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);
        name=findViewById(R.id.foodname1);
        quant=findViewById(R.id.quant);
        price=findViewById(R.id.price);
        tot=findViewById(R.id.billamt);
        tot_bill=findViewById(R.id.total_bill);
        paymode=findViewById(R.id.payment_mode);
        e=findViewById(R.id.error);

        //Toast.makeText(this, "pass-1", Toast.LENGTH_SHORT).show();
        Intent b=getIntent();
        String fname=b.getStringExtra("FoodName");
        String fprice=b.getStringExtra("Price");
        String quantity=b.getStringExtra("Quantity");

        //Toast.makeText(this, "pass-2", Toast.LENGTH_SHORT).show();
        name.setText(fname);
        price.setText(fprice);
        quant.setText(quantity);

        //Toast.makeText(this, "pass-3", Toast.LENGTH_SHORT).show();
        try
        {
            int price_val=Integer.parseInt(price.getText().toString());
            int quant_val=Integer.parseInt(quant.getText().toString());
            double bill_val=price_val*quant_val;
            val=(bill_val+10.25+10.50);

           // Toast.makeText(this, "pass-4", Toast.LENGTH_SHORT).show();
            tot.setText(""+(int)bill_val);
            tot_bill.setText(""+val);

        }
        catch (Exception ex)
        {
          //  Toast.makeText(this, ex+"", Toast.LENGTH_SHORT).show();
            e.setText(e.toString());
        }

        paymode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p1=new Intent(BillActivity.this,PaymentActivity.class);
                p1.putExtra("Bill_Val",""+val);
                startActivity(p1);
            }
        });
    }
}