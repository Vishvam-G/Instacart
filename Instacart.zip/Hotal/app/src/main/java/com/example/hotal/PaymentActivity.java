package com.example.hotal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class PaymentActivity extends AppCompatActivity {

    RadioGroup rg;
    Button pay_b;

    Boolean IsPaymentChoiceSelected=false;
    String payMethod="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        rg=findViewById(R.id.paymentChoice);
        pay_b=findViewById(R.id.pay_bill);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i)
            {
                if(i==R.id.payCash)
                {
                    IsPaymentChoiceSelected=true;
                    payMethod="Via Cash";
                }
                else if(i==R.id.payNetBank)
                {
                    IsPaymentChoiceSelected=true;
                    payMethod="Via Net-Banking";
                }
                else if(i==R.id.payCard)
                {
                    IsPaymentChoiceSelected=true;
                    payMethod="Via Card";
                }
                else if(i==R.id.payUPI)
                {
                    IsPaymentChoiceSelected=true;
                    payMethod="Via UPI";
                }
                else
                {
                    IsPaymentChoiceSelected=false;
                    Toast.makeText(PaymentActivity.this, "Invalid Choice", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Intent o=getIntent();
        String value=o.getStringExtra("Bill_Val");

        pay_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(IsPaymentChoiceSelected)
                {
                    Intent pb=new Intent(PaymentActivity.this,RecieptActivity.class);
                    pb.putExtra("Bill_Amt",value);
                    pb.putExtra("pay_meth",payMethod);
                    startActivity(pb);
                }
                else
                {
                    Toast.makeText(PaymentActivity.this, "Please selecte payment mode", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}